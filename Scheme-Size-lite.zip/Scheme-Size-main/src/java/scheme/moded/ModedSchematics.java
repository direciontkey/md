package scheme.moded;

import arc.files.Fi;
import arc.math.geom.Point2;
import arc.struct.IntMap;
import arc.struct.Seq;
import arc.struct.StringMap;
import arc.util.Log;
import arc.util.Reflect;
import arc.util.Strings;
import arc.util.Structs;
import arc.util.io.Reads;
import arc.util.serialization.Base64Coder;
import mindustry.content.Blocks;
import mindustry.ctype.ContentType;
import mindustry.game.Schematic;
import mindustry.game.Schematics;
import mindustry.game.Schematic.Stile;
import mindustry.io.*;
import mindustry.world.Block;
import mindustry.world.blocks.legacy.LegacyBlock;
import mindustry.core.Version;

import static mindustry.Vars.*;

import java.io.*;
import java.util.zip.InflaterInputStream;

/** Schematics loader that understands schematics larger than the vanilla 128x128 hard limit. */
public class ModedSchematics extends Schematics {

    /** Too large schematic file extension. */
    public static final String largeSchematicExtension = "mtls";

    /** Copy paste from {@link Schematics}. */
    public static final byte[] header = { 'm', 's', 'c', 'h' };

    /** The biggest width or height vanilla is able to read. */
    public static final int vanillaLimit = 128;

    /** Do need to show the dialog. */
    public boolean requiresDialog;

    /** Don't bother rewriting large schematics if using foo's client. */
    private static boolean isFoos = Structs.contains(Version.class.getDeclaredFields(), field -> field.getName().equals("foos"));

    // region too large schematics fix

    @Override
    public void loadSync() {
        super.loadSync();
        for (Fi file : schematicDirectory.list()) fix(file);
    }

    /** Schematics that vanilla can't read are saved as .mtls right away, so they never depend on being renamed at the next launch. */
    @Override
    public void add(Schematic schematic) {
        if (!isLarge(schematic)) {
            super.add(schematic);
            return;
        }

        all().add(schematic);
        try {
            Fi file = findLargeFile(Strings.sanitizeFilename(schematic.name()));
            write(schematic, file);
            schematic.file = file;
        } catch (Exception error) {
            ui.showException(error);
            Log.err(error);
        }
        all().sort();
    }

    /** Same as above, but for a schematic that was saved over an existing one and may have outgrown it. */
    @Override
    public void overwrite(Schematic target, Schematic newSchematic) {
        super.overwrite(target, newSchematic);

        if (!isLarge(target) || target.file == null || !target.file.extension().equals(schematicExtension)) return;

        Fi moved = rename(target.file);
        target.file = moved;
        newSchematic.file = moved;
    }

    private void fix(Fi file) { // don't check size for mtls files
        if (!file.extension().equals(largeSchematicExtension) && !isTooLarge(file)) return;

        try {
            if (file.extension().equals(schematicExtension)) {
                Fi moved = rename(file);
                if (moved != file) requiresDialog = true; // show dialog on startup
                file = moved;
            }
            all().add(read(file));
        } catch (Throwable error) {
            Log.err("Failed to read schematic from file '@'", file);
            Log.err(error);
        }
    }

    private static boolean isLarge(Schematic schematic) {
        return !isFoos && (schematic.width > vanillaLimit || schematic.height > vanillaLimit);
    }

    private static boolean isTooLarge(Fi file) {
        if (isFoos) return false;
        try (DataInputStream stream = new DataInputStream(file.read())) {
            for (byte b : header)
                if (stream.read() != b) return false; // missing header

            stream.skip(1L); // schematic version or idk what is it

            DataInputStream dis = new DataInputStream(new InflaterInputStream(stream));
            return dis.readShort() > vanillaLimit || dis.readShort() > vanillaLimit; // next two shorts is a width and height
        } catch (Throwable ignored) {
            return false;
        }
    }

    /** Moves the file to a free .mtls name, or returns the same file if it could not be moved. */
    private static Fi rename(Fi file) {
        Fi folder = file.parent();
        String name = file.nameWithoutExtension();

        Fi dest = folder.child(name + "." + largeSchematicExtension);
        for (int i = 1; dest.exists(); i++)
            dest = folder.child(name + "_" + i + "." + largeSchematicExtension);

        return file.file().renameTo(dest.file()) ? dest : file;
    }

    /** Finds a name that is free for both extensions, so the files never shadow each other. */
    private static Fi findLargeFile(String name) {
        if (name.isEmpty()) name = "empty";

        Fi result;
        String base;
        int index = 0;
        do {
            base = name + (index == 0 ? "" : "_" + index);
            result = schematicDirectory.child(base + "." + largeSchematicExtension);
            index++;
        } while (result.exists() || schematicDirectory.child(base + "." + schematicExtension).exists());

        return result;
    }

    public static Schematic readBase64(String schematic) {
        try {
            return read(new ByteArrayInputStream(Base64Coder.decode(schematic.trim())));
        } catch (IOException error) {
            throw new RuntimeException(error);
        }
    }

    public static Schematic read(Fi file) throws IOException {
        Schematic schematic = read(new DataInputStream(file.read(1024)));
        schematic.file = file;

        if (!schematic.tags.containsKey("name")) schematic.tags.put("name", file.nameWithoutExtension());

        return schematic;
    }

    public static Schematic read(InputStream input) throws IOException {
        input.skip(4L); // header bytes already checked
        int ver = input.read();

        try (DataInputStream stream = new DataInputStream(new InflaterInputStream(input))) {
            short width = stream.readShort(), height = stream.readShort();

            StringMap map = new StringMap();
            int tags = stream.readUnsignedByte();
            for (int i = 0; i < tags; i++)
                map.put(stream.readUTF(), stream.readUTF());

            String[] labels = null;
            try { // try to read the categories, but skip if it fails
                labels = JsonIO.read(String[].class, map.get("labels", "[]"));
            } catch (Exception ignored) {}

            IntMap<Block> blocks = new IntMap<>();
            byte length = stream.readByte();
            for (int i = 0; i < length; i++) {
                String name = stream.readUTF();
                Block block = content.getByName(ContentType.block, SaveFileReader.fallback.get(name, name));
                blocks.put(i, block == null || block instanceof LegacyBlock ? Blocks.air : block);
            }

            int total = stream.readInt();
            Seq<Stile> tiles = new Seq<>(total);
            for (int i = 0; i < total; i++) {
                Block block = blocks.get(stream.readByte());
                int position = stream.readInt();
                Object config = ver == 0 ?
                        Reflect.invoke(Schematics.class, "mapConfig", new Object[] { block, stream.readInt(), position }, Block.class, int.class, int.class) :
                        TypeIO.readObject(Reads.get(stream));
                if (block != Blocks.air)
                    tiles.add(new Stile(block, Point2.x(position), Point2.y(position), config, stream.readByte()));
            }

            Schematic out = new Schematic(tiles, map, width, height);
            if (labels != null) out.labels.addAll(labels);
            return out;
        }
    }
}
