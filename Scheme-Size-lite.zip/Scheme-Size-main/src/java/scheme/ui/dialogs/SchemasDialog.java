package scheme.ui.dialogs;

import arc.scene.Element;
import arc.scene.style.Drawable;
import arc.scene.ui.ImageButton;
import arc.scene.ui.TextButton;
import arc.scene.ui.layout.Cell;
import arc.scene.ui.layout.Table;
import arc.util.Reflect;
import mindustry.game.Schematic;
import mindustry.gen.Icon;
import mindustry.gen.Tex;
import mindustry.ui.Styles;
import mindustry.ui.dialogs.BaseDialog;
import mindustry.ui.dialogs.SchematicsDialog;
import scheme.compat.GameCompat;
import scheme.moded.ModedSchematics;

import static arc.Core.*;
import static mindustry.Vars.*;

/** Schematics menu whose import dialog can read schematics larger than vanilla allows. */
public class SchemasDialog extends SchematicsDialog {

    /** Replaces the vanilla schematics menu with this one. */
    public static void install() {
        ui.schematics = new SchemasDialog();

        if (!mobile) return;

        // the vanilla HUD button keeps a reference to the old dialog, so it has to be rewired
        ImageButton button = findButton();
        if (button == null || button.getListeners().size <= 2) return;

        button.getListeners().remove(2);
        button.clicked(ui.schematics::show);
    }

    private static ImageButton findButton() {
        Element overlay = ui.hudGroup.find("overlaymarker");
        if (!(overlay instanceof Table)) return null;

        return findByName((Table) overlay, "schematics");
    }

    private static ImageButton findByName(Table table, String name) {
        for (Element e : table.getChildren()) {
            if (name.equals(e.name) && e instanceof ImageButton) {
                return (ImageButton) e;
            }
            if (e instanceof Table) {
                ImageButton found = findByName((Table) e, name);
                if (found != null) return found;
            }
        }
        return null;
    }

    @Override
    public void showImport() {
        new ImportDialog().show();
    }

    public void imported(Schematic schematic) {
        Reflect.invoke(SchematicsDialog.class, this, "setup", null);
        Reflect.invoke(SchematicsDialog.class, this, "checkTags", new Object[] { schematic }, Schematic.class);
        showInfo(schematic);

        schematic.removeSteamID();
        schematics.add(schematic);
    }

    public class ImportDialog extends BaseDialog {

        public ImportDialog() {
            super("@editor.export");
            addCloseButton();

            cont.pane(pane -> {
                pane.margin(10f);
                pane.table(Tex.button, t -> {
                    t.defaults().size(280f, 60f).left();

                    button(t, "copy.import", Icon.copy, () -> {
                        try {
                            imported(ModedSchematics.readBase64(app.getClipboardText()));
                            ui.showInfoFade("@schematic.saved");
                        } catch (Throwable error) {
                            ui.showException(error);
                        }
                    }).disabled(b -> app.getClipboardText() == null || !app.getClipboardText().startsWith(schematicBaseStart)).row();

                    button(t, "importfile", Icon.download, () -> GameCompat.openFile(schematicExtension, file -> {
                        try {
                            imported(ModedSchematics.read(file));
                        } catch (Throwable error) {
                            ui.showException(error);
                        }
                    })).row();

                    if (!steam) return;

                    button(t, "browseworkshop", Icon.book, () -> platform.openWorkshop());
                });
            });
        }

        private Cell<TextButton> button(Table table, String text, Drawable image, Runnable listener) {
            return table.button("@schematic." + text, image, Styles.flatt, () -> {
                hide();
                listener.run();
            }).marginLeft(12f);
        }
    }
}
