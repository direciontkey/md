package scheme;

import mindustry.game.Schematics;
import mindustry.mod.Mod;
import scheme.moded.ModedSchematics;
import scheme.ui.dialogs.SchemasDialog;

import static arc.Core.*;
import static mindustry.Vars.*;

public class Main extends Mod {

    /** Replacement for the vanilla schematics loader, null if it was not installed. */
    private ModedSchematics moded;

    public Main() {
        maxSchematicSize = 512;

        if (headless || schematics == null) return;

        if (schematics.getClass().getSimpleName().startsWith("Moded")) return;

        assets.load(schematics = moded = new ModedSchematics());
        assets.unload(Schematics.class.getSimpleName());
    }

    @Override
    public void init() {
        if (headless) return;

        SchemasDialog.install();

        if (moded != null && moded.requiresDialog) ui.showOkText("@rename.name", "@rename.text", () -> {});
    }
}
