# !Scheme Size (schematic size only)

Stripped-down build of Mithra's port of [Scheme Size](https://github.com/xzxADIxzx/Scheme-Size) (`xzxADIxzx`). Unofficial - the original author is not involved.

It does one thing: **raises the schematic size limit to 512**. No settings, no buttons, no extra UI, no networking.

## What it contains

- `maxSchematicSize = 512`.
- A replacement schematic loader, so schematics bigger than 128 in width or height load from your schematics folder. Such `.msch` files are renamed to `.mtls`, and you get a one-time notice when that happens.
- The Schematics menu's import dialog (clipboard / file), so big schematics can be imported.

Everything else from the full port was removed: the mod settings category, HUD buttons, admin and server tools, CLaJ, AI, renderer and building tools, keybinds, image parser, updater and the console helpers.

## Install

Put `Scheme-Size.jar` into the client's `mods/` folder. Mindustry **156-159**, desktop and mobile.

## Build

```bash
./build-all.sh
```

Output: `dist/Scheme-Size.jar`

## Credit

- Original mod: [xzxADIxzx/Scheme-Size](https://github.com/xzxADIxzx/Scheme-Size)
- Port: Mithra ([ItsXeroc/Scheme-Size](https://github.com/ItsXeroc/Scheme-Size))
