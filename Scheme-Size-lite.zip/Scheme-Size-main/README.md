# !Scheme Size (schematic size only)

Stripped-down build of Mithra's port of [Scheme Size](https://github.com/xzxADIxzx/Scheme-Size) (`xzxADIxzx`). Unofficial - the original author is not involved.

It does one thing: **raises the schematic size limit to 512**. No settings, no buttons, no extra UI, no networking.

## What it contains

- `maxSchematicSize = 512`.
- A replacement schematic loader, so schematics bigger than 128 in width or height can be read.
- Schematics bigger than 128 are saved as `.mtls` right away (new, imported or overwritten ones). Vanilla ignores that extension, so with the mod turned off they stay untouched in the `schematics` folder and show up again when the mod is back on.
- Old oversized `.msch` files are renamed to `.mtls` on launch (never overwriting another file), with a one-time notice.
- The Schematics menu's import dialog (clipboard / file), so big schematics can be imported.

Everything else from the full port was removed: the mod settings category, HUD buttons, admin and server tools, CLaJ, AI, renderer and building tools, keybinds, image parser, updater and the console helpers.

## Install

Put `Scheme-Size.jar` into the client's `mods/` folder. Mindustry **156-159**, desktop and mobile.

## Build

```bash
./build-all.sh
```

Output: `dist/Scheme-Size.jar`

## Credit

- Original mod: [xzxADIxzx/Scheme-Size](https://github.com/xzxADIxzx/Scheme-Size)
- Port: Mithra ([ItsXeroc/Scheme-Size](https://github.com/ItsXeroc/Scheme-Size))
